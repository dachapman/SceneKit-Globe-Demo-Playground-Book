/*:
 # SceneKit - Photo Texture
 */
//#-hidden-code
import SceneKit
import PlaygroundSupport // needed to create the live view
//#-end-hidden-code

/*:
 Third, we add a texture to our earth.  Texture maps wrap a photo onto your object.
 
 The image we will be wrapping around the sphere looks like this:
 
 ![earth texture](earth_texture.png "photo of the earth")
 
 FYI, this photograph was made by NASA where they looked through satellite images of the earth's surface for
 times when the surface was not obscurred by clouds and stitched the images together to form this awesome photo for us.
 
 If you prefer another look to your earth, we have provided a different photo texture that you can try:
 
 ![alt earth texture](alt_earth_texture.jpg "alternative photo of the earth")
 
 Here is the code from your previous work.  We will add our photo-realistic texture to the sphere below:
 
 */

//#-editable-code
//#-copy-destination("Page1.playgroundpage", sceneCode)
let scene = SCNScene()
//#-end-copy-destination
//#-end-editable-code

//#-editable-code
//#-copy-destination("Page1.playgroundpage", id1)
let globe = SCNNode()
globe.geometry = SCNSphere(radius: 1.0)
scene.rootNode.addChildNode(globe)
//#-end-copy-destination
//#-end-editable-code

//#-editable-code
//#-copy-destination("Page2.playgroundpage", id2)
globe.geometry?.firstMaterial?.normal.contents = #imageLiteral(resourceName: "earth_normalmap.jpg")
//#-end-copy-destination
//#-end-editable-code

/*:
 Type the line below to add elevation and texture to your earth:
 
 ````
 globe.geometry?.firstMaterial?.diffuse.contents = #imageLiteral(resourceName: "earth_texture.png")
 
 ````
 
 Then run the playground and drag the earth to spin and pinch to zoom in and out.
 
 */

//#-copy-source(id3)
//#-editable-code

//#-end-editable-code
//#-end-copy-source


//#-hidden-code
let view = SCNView() //iPad version
//let view = SCNView(frame: CGRect(x: 0, y: 0, width: 400, height: 600)) //Xcode version
view.allowsCameraControl = true
view.autoenablesDefaultLighting = true
view.showsStatistics = true
view.scene = scene
view.backgroundColor = #colorLiteral(red: 0.0470588244497776, green: 0.0, blue: 0.129411771893501, alpha: 1.0)
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = view
PlaygroundPage.current.assessmentStatus = .pass(message: nil)
//#-end-hidden-code
