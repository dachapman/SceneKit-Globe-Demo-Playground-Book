/*:
 # SceneKit - Creating a Scene and a Node
 */
//#-hidden-code
import SceneKit
import PlaygroundSupport // needed to create the live view
//#-end-hidden-code
/*:
  First, we make a scene.  Type the line below:

  ````
  let scene = SCNScene()
  ````
 */
// make a scene below
//#-copy-source(sceneCode)
//#-editable-code
//#-end-editable-code
//#-end-copy-source
/*:
  Make a 3D object (a node).  Type the line below:

  ````
  let globe = SCNNode()
  globe.geometry = SCNSphere(radius: 1.0)
  scene.rootNode.addChildNode(globe)
  ````
 */
// Make a node (a sphere) and add it to the scene

//#-copy-source(id1)
//#-editable-code
//#-end-editable-code
//#-end-copy-source

//#-hidden-code
let view = SCNView() //iPad version
//let view = SCNView(frame: CGRect(x: 0, y: 0, width: 400, height: 600)) //Xcode version
view.allowsCameraControl = true
view.autoenablesDefaultLighting = true
view.showsStatistics = true
view.scene = scene
view.backgroundColor = #colorLiteral(red: 0.0470588244497776, green: 0.0, blue: 0.129411771893501, alpha: 1.0)
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = view
PlaygroundPage.current.assessmentStatus = .pass(message: nil)
//#-end-hidden-code

