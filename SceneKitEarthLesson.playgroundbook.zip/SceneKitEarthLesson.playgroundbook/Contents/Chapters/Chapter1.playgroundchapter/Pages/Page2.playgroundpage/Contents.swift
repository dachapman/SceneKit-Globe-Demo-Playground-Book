/*:
 # SceneKit - Bump Maps
 */
//#-hidden-code
import SceneKit
import PlaygroundSupport // needed to create the live view
//#-end-hidden-code

/*:
 Second, we add a bump map to our sphere.  Bump maps show 3-D texture or elevation to your object.
 
 The image we will be wrapping around the sphere looks like this:
 
 ![earth bump map](earth_normalmap.jpg "elevation map of the earth")
 
 Below is the code you entered on previous pages.  We will then add to this below:
 */

//#-editable-code
//#-copy-destination("Page1.playgroundpage", sceneCode)
let scene = SCNScene()
//#-end-copy-destination
//#-end-editable-code

//#-editable-code
//#-copy-destination("Page1.playgroundpage", id1)
let globe = SCNNode()
globe.geometry = SCNSphere(radius: 1.0)
scene.rootNode.addChildNode(globe)
//#-end-copy-destination
//#-end-editable-code

/*:
 Type the line below to add elevation and texture to your earth:
 
 ````
 globe.geometry?.firstMaterial?.normal.contents = #imageLiteral(resourceName: "earth_normalmap.jpg")
 
 ````
 
 Then run the playground and drag the earth to spin and pinch to zoom in and out.
 */

//#-copy-source(id2)
//#-editable-code
//#-end-editable-code
//#-end-copy-source


//#-hidden-code
let view = SCNView() //iPad version
//let view = SCNView(frame: CGRect(x: 0, y: 0, width: 400, height: 600)) //Xcode version
view.allowsCameraControl = true
view.autoenablesDefaultLighting = true
view.showsStatistics = true
view.scene = scene
view.backgroundColor = #colorLiteral(red: 0.0470588244497776, green: 0.0, blue: 0.129411771893501, alpha: 1.0)
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = view
PlaygroundPage.current.assessmentStatus = .pass(message: nil)
//#-end-hidden-code
