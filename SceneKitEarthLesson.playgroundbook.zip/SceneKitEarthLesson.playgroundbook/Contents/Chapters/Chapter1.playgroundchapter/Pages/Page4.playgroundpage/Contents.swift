/*:
 # SceneKit - Photo Texture
 */
//#-hidden-code
import SceneKit
import PlaygroundSupport // needed to create the live view
//#-end-hidden-code

/*:
 Fourth, let's add some relfection to our earth - specifically specular reflection.  Specular reflection is the mirror-like reflection of light off a surface.add
 
 In this photograph, the light from the clouds and sky are reflected off the water surface to the person taking the photograph.  In contrast, the light from the sky and clouds
 are absorbed by the land mass and therefore not reflected.absorbed
 
 Light hitting a surface has three possible outcomes:  1) it can be absorbed by the surface, 2) it can pass through the surface (transmission), or 3) it can be reflected by the surface.
 ![photo of light reflection off water](specular_reflection.jpg "reflection of light")
 
 On our globel, we want the water to reflect the light coming at it back to the observer and we want the land to absorb the light and not be so reflective.  We will wrap a map around our
 globel that defines the water to be very reflective and the land areas to be non-reflective.and
 
 Here is the map that defines these land/water differences.
 
 ![map of water and land for specular reflecation](specular.tif "land/ocean mask ")
 
 Here is the code you entered on previous pages.  We will add code to do the specular reflection below:
 
 */

//#-editable-code
//#-copy-destination("Page1.playgroundpage", sceneCode)
let scene = SCNScene()
//#-end-copy-destination
//#-end-editable-code

//#-editable-code
//#-copy-destination("Page1.playgroundpage", id1)
let globe = SCNNode()
globe.geometry = SCNSphere(radius: 1.0)
scene.rootNode.addChildNode(globe)
//#-end-copy-destination
//#-end-editable-code

//#-editable-code
//#-copy-destination("Page2.playgroundpage", id2)
globe.geometry?.firstMaterial?.normal.contents = #imageLiteral(resourceName: "earth_normalmap.jpg")
//#-end-copy-destination
//#-end-editable-code

//#-editable-code
//#-copy-destination("Page3.playgroundpage", id3)
globe.geometry?.firstMaterial?.diffuse.contents = #imageLiteral(resourceName: "earth_texture.png")
//#-end-copy-destination
//#-end-editable-code

/*:
 
 Type the line below to add elevation and texture to your earth:
 
 ````
 globe.geometry?.firstMaterial?.specular.contents = #imageLiteral(resourceName: "specular.tif")
 
 ````
 
 Then run the playground and drag the earth to spin and pinch to zoom in and out.
 
 */

//#-copy-source(id4)
//#-editable-code
//#-end-editable-code
//#-end-copy-source


//#-hidden-code
let view = SCNView() //iPad version
//let view = SCNView(frame: CGRect(x: 0, y: 0, width: 400, height: 600)) //Xcode version
view.allowsCameraControl = true
view.autoenablesDefaultLighting = true
view.showsStatistics = true
view.scene = scene
view.backgroundColor = #colorLiteral(red: 0.0470588244497776, green: 0.0, blue: 0.129411771893501, alpha: 1.0)
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = view
PlaygroundPage.current.assessmentStatus = .pass(message: nil)
//#-end-hidden-code
